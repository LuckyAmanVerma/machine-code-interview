import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { NotFound,Home } from '@/features';


const App: React.FC = () => {
  return (
    <Router>
      <div>
        <h1>Machine Code Interview</h1>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;